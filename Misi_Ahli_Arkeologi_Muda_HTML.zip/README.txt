MISI AHLI ARKEOLOGI MUDA — STARTER WEBSITE
Bahasa: Melayu
Halaman: index.html, objektif.html, kandungan.html, aktiviti.html, pentaksiran.html, maklum-balas.html
Aset: assets/style.css, assets/app.js

PENTING:
1. Ini ialah prototaip awal untuk pembangunan Tugasan 3, bukan produk akhir yang telah disahkan.
2. Semak kandungan Sejarah dengan DSKP dan sumber rasmi sebelum penerbitan.
3. Gantikan ruang video, ikon contoh dan bahan visual dengan OPD yang benar-benar dibangunkan sendiri serta disemak.
4. Uji semua pautan dan kuiz selepas hos.
5. Refleksi pada prototaip ini tidak disimpan ke pangkalan data.
6. Untuk Google Sites, hoskan folder ini pada perkhidmatan yang menyokong HTML/CSS/JS (contohnya GitHub Pages), kemudian gunakan Insert > Embed > URL dalam Google Sites. Google Sites tidak semestinya menjalankan satu set fail HTML lengkap apabila kod ditampal terus ke editor.
